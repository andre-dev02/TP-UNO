#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste gerar numeros amarelos"){
    CHECK(GerarNumeroAmarelo()); //numeros aleatorios pela quantidade de numeros passadosno parametros
    CHECK(GerarNumeroAmarelo()); // dIFERENTE DE 10

}