#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TEST_CASE("Teste retira a carta") {
    CHECK(retiracarta()); //ver se a carta é da cor e número - testar a cor
    CHECK(retiracarta()); //ver se a carta é da cor e número - testar o numero

}