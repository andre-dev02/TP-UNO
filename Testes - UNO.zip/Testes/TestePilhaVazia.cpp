#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste pilha vazia") {
    CHECK(pilha_vazia()); //passar por toda a lista - se tiver vazia = 1 - nullptr
    CHECK(pilha_vazia()); //passar por toda a lista - se não tiver vazia = 0 
}