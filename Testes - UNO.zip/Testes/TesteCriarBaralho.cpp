#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste criar baralho") { //inicializar todas as cartas
    CHECK(criar_baralho()); // pilhas com 0 (todas)
    CHECK(criar_baralho()); //passar parametros de gerar as cartas- especiais e numeros todas as cores 
}