#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste gerar numeros azul"){
    CHECK(GerarNumeroAzul()); //numeros aleatorios pela quantidade de numeros passadosno parametros
    CHECK(GerarNumeroAzul()); // dIFERENTE DE 10

}