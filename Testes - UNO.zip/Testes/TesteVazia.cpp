#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TESTE_CASE("Testar vazia") {
    CHECK (vazia(null) == 1); //ver se está vazia - se sim é o vencedor
    CHECK (vazia(1) == 0); //ver se não está (com 2 carta) - segue o jogo normal
    CHECK (vazia(2) == 0); //ver se não está (com 1 carta) - segue o jogo normal
    CHECK (vazia(7) == 0); 
    CHECK (vazia(15) == 0); 
}