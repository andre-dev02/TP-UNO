#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TEST_CASE("Teste inicializa") {
    CHECK(inicializa() == NULL); // devolver null
    CHECK(inicializa(2) != NULL);
}