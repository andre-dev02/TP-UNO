#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste Altura da Pilha"){ //Imprime a quantidade de cartas e retorna o valor
    CHECK(altura_pilha()) // chamar cheia
    CHECK(altura_pilha()) // chamar vazia
}