#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste Pilha Cheia") {
    CHECK(pilha_cheia()); //se o (maximo - 1) for igual ao fim ou topo da pilha retornar verdadeiro 
    CHECK(pilha_cheia()); //se o (maximo - 1) for diferente ao fim ou topo da pilha retornar Falso 
    
}