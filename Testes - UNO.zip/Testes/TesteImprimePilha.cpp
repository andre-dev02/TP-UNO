#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste Imprime Pilha") { //numero e cor 
    CHECK(imprime_pilha()); //pilha diferente de vazio (vazia nao imprime)
    CHECK(imprime_pilha());//(vazia nao imprime)
    CHECK(imprime_pilha()); //Valor e imprime o valor da pilha
}