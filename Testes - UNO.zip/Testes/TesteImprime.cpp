#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TEST_CASE("Teste imprime") {
    Mao* p ;

    CHECK (imprime (1) = ); //imprimir sete cartas para o jogador no início
    CHECK (imprime (null) == 0); //
}