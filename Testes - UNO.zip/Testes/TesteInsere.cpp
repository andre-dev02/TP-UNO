#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TEST_CASE("Teste insere") {
    CHECK(insere (c, 1, 2) = ); //Jogador 1
    CHECK(insere ()); //Jogador 2
}