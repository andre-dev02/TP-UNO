#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TEST_CASE("Teste Criar mao") {
    CHECK(criar_mao); //ver se tem 7 cartas na mao do jogaor1
    CHECK(criar_mao); //ver se tem 7 cartas na mao do jogaor2
}

