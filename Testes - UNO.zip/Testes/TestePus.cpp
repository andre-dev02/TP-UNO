#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste push") {
    CHECK(push()); // Pilha cheia retorna 0
    CHECK(push()); // se não estiver cheia add nova carta
}

