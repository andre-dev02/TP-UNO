#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste gerar numeros verde"){
    CHECK(GerarNumeroVerde()); //numeros aleatorios pela quantidade de numeros passadosno parametros
    CHECK(GerarNumeroVerde()); // dIFERENTE DE 10

}