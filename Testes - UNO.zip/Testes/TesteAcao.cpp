#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TEST_CASE("Teste acao") {
    CHECK(acao()); //add 2 cartas na pilha 
    CHECK(acao()); //add 4 cartas na pilha 
    CHECK(acao()); //muda cor 
}