#ifndef MAO_H
#define MAO_H
#include "baralho.hpp"
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
 
using namespace std;
 
struct mao { //mao do jogador
    carta c;
    struct mao* prox;
};
typedef struct mao Mao;
 
Mao* inicializa (void){
 return NULL;
}

Mao* insere (Mao* l, carta c){ // insere a carta na mao "
 Mao* novo = (Mao*) malloc(sizeof(Mao));
 novo->c = c;
 novo->prox = l;
 return novo;
}
 
int vazia (Mao* l) {//verifica se a mao ta vazia, se sim o jogador vence a partida
 if (l == NULL) {
 return 1;
 }else
 return 0;
}
//No TP foi utilizado a tabela ASCII para ser usado os caracteres nas cartas especiais,
// exemplo de como foi a transformação dos caracteres (+, M, R, T, B)
 
void imprime (Mao* l) { //mostra as cartas do jogador
 Mao* p;
 for (p = l; p != NULL; p = p->prox) {
        if (p->c.numero == 66) {
            cout << "Cor = " << p->c.cor << " Numero = Block" << endl;
        }
        if (p->c.numero == 82) {
            cout << "Cor = " << p->c.cor << " Numero = Reverse" << endl;
        }
        if (p->c.numero == 77) {
            cout << "Cor = " << p->c.cor << " Numero = +4" << endl;
        }
        if (p->c.numero == 43) {
            cout << "Cor = " << p->c.cor << " Numero = +2" << endl;
        }
        if (p->c.numero == 84) {
            cout << "Cor = " << p->c.cor << " Numero = Troca de cor" << endl;  
        }
        if (p->c.numero < 10) {
            cout << "Cor = " << p->c.cor << " Numero = " << p->c.numero << endl;
        }
        }
}
 
int tamanho(Mao* l, int id) { // Conta e mosta na tela quantas cartas o jogador tem
    int cont=0;
   
    Mao* p;
    p = l;
   
    while (p!=NULL) {
        cont++;
        p=p->prox;
    }
    cout << "Numero de cartas: " << cont << endl << endl;
 
    if ( cont == 0 ){ // Se o jogador ganha
        system("cls");
       
        cout << setw(120) << "         UU     UU     NN     N      OOOO      |" << endl;
        cout << setw(120) << "         UU     UU     NN NN  N    OO    OO    |" << endl;
        cout << setw(120) << "         UU     UU     NN  NN N    OO    OO    |" << endl;
        cout << setw(120) << "           UUUUU       NN    NN      OOOO      o" << endl << endl << endl;
 
        cout << setw(120) << "                  Vitoria do jogador " << id << "!"<< endl;
        cout << setw(120) << "                        PARABENS!!!";
        exit(0); // Fecha o jogo
    }
    return cont;
}
 
 
Mao* acao(pilha *baralho, Mao *jogador,int numero){ // Se o numero for 43 ou 77  entra na funcao das cartas "+2" e "+4"
    carta c;
    if (numero == 43){
    for (int i = 0 ; i < 2 ; i++){
    pop(baralho,&c);
    jogador = insere(jogador ,c);
        }
    }
   
    if (numero == 77){
    for (int i = 0 ; i < 4 ; i++){
    pop(baralho,&c);
    jogador = insere(jogador ,c);
        }
    }
   
    return jogador;
}
 
Mao* retiracarta (Mao* jogador, carta c, pilha *mesa, pilha *baralho,int cor, int num) {
 
 Mao* ant = NULL;
 Mao* p = jogador;
 
 
 while (p != NULL && (p->c.numero != c.numero)  ) { //verificar a cor
 ant = p;
 p = p->prox;
}
 
 
while (p != NULL && (p->c.cor != c.cor ) ) { //verificar o numero        
 ant = p;
 p = p->prox;
}
 
 
        pop(mesa,&c); //verifica as cartas da mesa
    if(p->c.cor != c.cor && p->c.numero != c.numero ){  //se o jogador joga a carta errada recebe essa mensagem, perde a vez de jogar e a mesa pega a carta de volta
        push(mesa,c);
        cout << "Nao tente roubar jogue somente a carta certa!" << endl << endl;
        pop(baralho,&c);
        jogador = insere(jogador,c);
        Sleep(3000);
     return jogador;
   
    } else { //se o jogador joga a carta certa, esta eh inserida na pilha
    c.cor = cor;
    c.numero = num;
    push(mesa,c);
   
 //encontrou o elemento?
 if (p == NULL)
 return jogador; //nao -> retorna lista original e retira elemento
 if (ant == NULL) { // retira elemento do inicio
 jogador = p->prox;
 }
 else { // retira elemento do meio da lista
 ant->prox = p->prox;
 }
 free(p);
 return jogador;
}
}
//}
 
 
Mao* criar_mao(pilha *baralho, Mao *jogador) { //tira a carta do baralho e coloca na mao dos jogadores e tira o elemento da pilha e coloca na lista
    carta c;
    jogador = inicializa();
       
    for (int i = 0 ; i < 7 ; i++) {
        pop(baralho,&c);
        jogador = insere(jogador,c);
    }  
   
    return jogador;
}
 
 
 
#endif
