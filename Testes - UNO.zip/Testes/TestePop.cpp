#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste pop") {
    CHECK(pop()); //pilha vazia retorna 0
    CHECK(pop()); //pilha não vazia remove carta do topo
}

