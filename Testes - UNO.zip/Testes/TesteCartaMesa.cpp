#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste Carta na Mesa"){
    CHECK(carta_mesa()); //inicializar mesa (pilha onde jogo as cartas - tem ue estar vazia)
    CHECK(carta_mesa()); // Receber uma carta - tira do baralho e poe na mesa uma carta só - a do início do jogo
    
}