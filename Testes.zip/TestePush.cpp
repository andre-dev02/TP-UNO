#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste push") {
    CHECK(push(p = 108, c = 2 2) == 0); // Pilha cheia retorna 0
    CHECK(push(p = 12, c = 0 3) == 1); // se não estiver cheia add nova carta
    CHECK(push(p = 0, c = 0 4) == 1);
    CHECK(push(p = 53, c = 1 2) == 1);
}

