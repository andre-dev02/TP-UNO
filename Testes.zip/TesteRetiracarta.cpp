#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TEST_CASE("Teste retira a carta") {
    CHECK(retiracarta(5, c [4], 10, 44, 0, 7) == 4); //ver se a carta é da cor e número - testar a cor
    CHECK(retiracarta(5, c [7], 5, 12, 2, 9) == 4); //ver se a carta é da cor e número - testar o numero

}