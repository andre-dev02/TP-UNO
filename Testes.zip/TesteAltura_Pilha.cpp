#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste Altura da Pilha"){ //Imprime a quantidade de cartas e retorna o valor
    CHECK(altura_pilha(p = 53) == 54); // chamar cheia
    CHECK(altura_pilha(p = 10) == 11); // chamar vazia
    CHECK(altura_pilha(p = 0) == 1); // chamar vazia
}