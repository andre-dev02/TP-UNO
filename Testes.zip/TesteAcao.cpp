#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
#include "mao.hpp"

TEST_CASE("Teste acao") {
    CHECK(acao(12, 2, 43) == 4); //add 2 cartas na pilha - qual o primeiro int? Quantas cartas tem na pilha?
    CHECK(acao(16, 7, 43) == 9); //add 4 cartas na pilha 
    CHECK(acao(50, 6, 77) == 10); 
    CHECK(acao(50, 13, 77) == 17); //muda cor 
}