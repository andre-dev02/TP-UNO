#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TESTE_CASE("Testar tamanho") {
    CHECK(tamanho(0, 1) == 0); //- Teste 1: se tem 9 posição -> mostra que tem 9 cartas - Jogador 1
    CHECK(tamanho(0, 2) == 0); //- Teste 2:  se tem 9 posição -> mostra que tem 9 cartas - Jogador 2
    CHECK(tamanho(1, 1) == 1);
    CHECK(tamanho(1, 2) == 1);
    CHECK(tamanho(20, 2) == 20);
    CHECK(tamanho(7, 2) == 7);

}