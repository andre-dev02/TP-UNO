#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "baralho.hpp"

TEST_CASE("Teste pop") {
    CHECK(pop(p = 0, c = 0 0) == 0); //pilha vazia retorna 0
    CHECK(pop(p = 0, c = 2 1) == 0); 
    CHECK(pop(p = 20, c = 3 0) == 1);//pilha não vazia remove carta do topo
    CHECK(pop(p = 45, c = 1 3) == 1);
}

