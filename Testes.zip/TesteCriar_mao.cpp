#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TEST_CASE("Teste Criar mao") {
    CHECK(criar_mao (44, 0) == 7); //ver se tem 7 cartas na mao do jogaor1
    CHECK(criar_mao (20, 0) == 7); //ver se tem 7 cartas na mao do jogaor2
}

