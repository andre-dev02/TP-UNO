#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "mao.hpp"

TESTE_CASE("Testar vazia") {
    CHECK (vazia(l = NULL) == 1); //ver se está vazia - se sim é o vencedor
    CHECK (vazia(l = 1) == 0); //ver se não está (com 2 carta) - segue o jogo normal
    CHECK (vazia(l = 2) == 0); //ver se não está (com 1 carta) - segue o jogo normal
    CHECK (vazia(l = 7) == 0); 
    CHECK (vazia(l = 15) == 0); 
}